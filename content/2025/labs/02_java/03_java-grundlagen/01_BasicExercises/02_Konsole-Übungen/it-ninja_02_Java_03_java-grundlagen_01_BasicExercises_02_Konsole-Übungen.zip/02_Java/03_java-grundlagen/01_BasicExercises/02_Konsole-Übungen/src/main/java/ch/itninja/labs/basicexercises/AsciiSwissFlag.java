package ch.itninja.labs.basicexercises;

public class AsciiSwissFlag {

    private AsciiSwissFlag() {
        // Prevent instantiation
    }

    /**
     * Zeichne eine Schweizer Fahne. Die Fahne muss einen Rahmen haben. Du darfst dazu
     * folgende Zeichen verwenden:
     *
     * - Im Rahmen: '|', '-', '+'', Leerzeichen (' ')
     * - Innerhalb: '|', '-', '+', '*', '=', '@'', Leerzeichen (' ')
     */
    public static void printSwissFlag(){

        // IT-Ninja: Füge hier Deinen Code ein...

    }
}
