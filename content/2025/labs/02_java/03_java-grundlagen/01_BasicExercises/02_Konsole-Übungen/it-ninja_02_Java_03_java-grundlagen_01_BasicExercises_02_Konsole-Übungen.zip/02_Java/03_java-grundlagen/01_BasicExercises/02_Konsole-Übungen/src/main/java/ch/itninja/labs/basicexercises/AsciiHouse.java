package ch.itninja.labs.basicexercises;

public class AsciiHouse {

    private AsciiHouse() {
        // Prevent instantiation
    }

    /**
     * Zeichne ein Haus in der Konsole. Du darfst dazu folgende Zeichen verwenden:
     *
     * - '/', '\', '+', '-', '_', '[', ']', '|', Leerzeichen (' ')
     */
    public static void printHouse(){

        // IT-Ninja: Füge hier Deinen Code ein...

    }
}
