package ch.itninja.labs.basicexercises;

/**
 * Utility class providing methods for basic Hello World output.
 */
public class HelloWorld {

    private HelloWorld() {
        // Prevent instantiation
    }

    /**
     * Passe den Code an damit Hello World auf der Konsole ausgegeben wird.
     */
    public static void printHelloWorld(){

        // IT-Ninja: Füge hier Deinen Code ein...

    }
}



