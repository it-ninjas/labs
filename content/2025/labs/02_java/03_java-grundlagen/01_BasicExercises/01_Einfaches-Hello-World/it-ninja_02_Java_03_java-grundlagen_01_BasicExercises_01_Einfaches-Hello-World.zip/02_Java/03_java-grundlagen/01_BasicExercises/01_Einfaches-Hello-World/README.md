# Java Exercises - Einfaches Hello World

Hier kannst Du erste Erfahrungen sammeln mit einem einfachen Java Programm

## Voraussetzung
* Du bist bereit die nachfolgende Anleitung gründlich zu lesen.

<itninja download lab="All"/>

## Einführung

Der zur Übung gehörende Quellcode zeigt dir ein einfaches Programm, welches den Text `Hello World` auf die Konsole
ausgibt. Er soll dir helfen, dich mit der Entwicklungsumgebung (IntelliJ) vertraut zu machen.

## Aufgabe - Hello World

Schau Dir das Programm an und versuche es zum Laufen zu bringen. Versuche, ein paar kleine Änderungen am Programm 
vorzunehmen. 

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\Main.java](./source/#src-main-java):

```java
public class Main {
    public static void main(String[] args) {

        System.out.println("Hello, world!");
        System.out.println("Hello again, world!");
    }
}
```
