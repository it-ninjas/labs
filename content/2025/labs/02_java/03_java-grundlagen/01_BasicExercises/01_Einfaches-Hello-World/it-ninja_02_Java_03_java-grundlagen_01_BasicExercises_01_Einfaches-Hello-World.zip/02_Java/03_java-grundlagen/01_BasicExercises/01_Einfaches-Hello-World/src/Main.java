/**
 * Schau Dir das Programm an und versuche es zum Laufen zu bringen. Versuche, ein paar kleine Änderungen am Programm
 * vorzunehmen.
 */
public class Main {
    public static void main(String[] args) {

        System.out.println("Hello, world!");
        System.out.println("Hello again, world!");
    }
}
