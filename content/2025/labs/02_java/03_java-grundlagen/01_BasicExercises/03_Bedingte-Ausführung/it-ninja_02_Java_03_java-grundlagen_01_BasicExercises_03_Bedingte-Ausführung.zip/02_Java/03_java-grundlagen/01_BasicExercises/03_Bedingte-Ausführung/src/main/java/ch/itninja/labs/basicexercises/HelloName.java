package ch.itninja.labs.basicexercises;


/**
 * Utility class providing methods for basic Hello Name output.
 */
public class HelloName {

    private HelloName() {
        // Prevent instantiation
    }

    /**
     * Erstelle eine Variable, welche deinen Namen beinhaltet.
     * Gib Hello [name] auf der Konsole aus.
     */
    public static void printHelloName(){

        // IT-Ninja: Füge hier Deinen Code ein...

    }
}
