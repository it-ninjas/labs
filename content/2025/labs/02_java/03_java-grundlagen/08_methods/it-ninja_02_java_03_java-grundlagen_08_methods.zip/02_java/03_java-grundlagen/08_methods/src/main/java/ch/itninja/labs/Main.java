package ch.itninja.labs;

import ch.itninja.labs.basicexercises.FibonacciHelper;
import ch.itninja.labs.basicexercises.MessageHelper;
import ch.itninja.labs.basicexercises.NumberHelper;

/**
 * Entry point for the It-Ninja basic exercises.
 */
public class Main {
    public static void main(String[] args) {

        // Sample call for "Nachricht drucken"
        // IT-Ninja: Füge hier Deinen Code ein...

        // Sample call for "Minimum von drei Zahlen"
        // IT-Ninja: Füge hier Deinen Code ein...

        // Sample call for "Fibonacci"
        // IT-Ninja: Füge hier Deinen Code ein...
    }
}
