package ch.itninja.labs;

import ch.itninja.labs.basicexercises.FibonacciHelper;
import ch.itninja.labs.basicexercises.MessageHelper;
import ch.itninja.labs.basicexercises.NumberHelper;

/**
 * Entry point for the It-Ninja basic exercises.
 */
public class Main {
    public static void main(String[] args) {

        // Sample call for printMessage
        // IT-Ninja: Füge hier Deinen Code ein...

        // Sample call for minimumOfThree
        // IT-Ninja: Füge hier Deinen Code ein...

        // Sample call for fibonacci
        // IT-Ninja: Füge hier Deinen Code ein...
    }
}
