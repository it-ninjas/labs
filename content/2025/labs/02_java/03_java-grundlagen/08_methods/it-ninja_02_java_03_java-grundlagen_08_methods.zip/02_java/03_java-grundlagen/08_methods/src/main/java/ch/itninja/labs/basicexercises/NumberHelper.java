package ch.itninja.labs.basicexercises;

/**
 * Utility class providing helper methods for fibonacci operations.
 */
/**
 * Name der Methode: Bestimme selber einen passenden Namen für die Methode  
 * Funktion: Gibt die kleinste von 3 Zahlen zurück  
 * Parameter1: Erste Zahl [int]  
 * Parameter2: Zweite Zahl [int]  
 * Parameter3: Dritte Zahl [int]  
 * Rückgabewert: Kleinste der 3 Zahlen [int]  
 */
public class NumberHelper {

    // IT-Ninja: Füge hier Deinen Code ein...
}
