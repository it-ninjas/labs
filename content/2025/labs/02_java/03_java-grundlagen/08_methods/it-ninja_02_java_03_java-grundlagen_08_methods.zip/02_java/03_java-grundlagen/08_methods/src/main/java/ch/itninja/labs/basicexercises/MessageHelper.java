package ch.itninja.labs.basicexercises;

/**
 * Utility class providing helper methods for fibonacci operations.
 */
/**
 * Name der Methode: Bestimme selber einen passenden Namen für die Methode  
 * Funktion: Gibt eine Nachricht auf der Konsole aus, Format: Nachricht an [Name des Empfängers]: [Nachricht]  
 * Parameter1: Name des Empfängers [String]  
 * Parameter2: Nachricht [String]  
 * Rückgabewert: Keiner  
 */
public class MessageHelper {

    // IT-Ninja: Füge hier Deinen Code ein...
}
