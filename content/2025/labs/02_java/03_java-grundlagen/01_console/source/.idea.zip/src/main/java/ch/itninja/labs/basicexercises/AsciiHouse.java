package ch.itninja.labs.basicexercises;

public class AsciiHouse {

    private AsciiHouse() {
        // Prevent instantiation
    }

    //<itninja source lab="AsciiHouse">
    public static void printHouse(){

        //<itninja solution lab="AsciiHouse">
        System.out.println("   /\\");
        System.out.println("  /  \\");
        System.out.println(" /____\\");
        System.out.println(" |    |");
        System.out.println(" | [] |");
        System.out.println(" |____|");
        //</itninja>

    }
    //</itninja>
}
