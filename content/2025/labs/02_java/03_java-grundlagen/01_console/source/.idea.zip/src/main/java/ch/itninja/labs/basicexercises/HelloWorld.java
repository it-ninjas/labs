package ch.itninja.labs.basicexercises;

/**
 * Utility class providing methods for basic Hello World output.
 */
public class HelloWorld {

    private HelloWorld() {
        // Prevent instantiation
    }

    //<itninja source lab="HelloWorld">
    public static void printHelloWorld(){

        //<itninja solution lab="HelloWorld">
        System.out.println("Hello World");
        //</itninja>

    }
    //</itninja>
}



