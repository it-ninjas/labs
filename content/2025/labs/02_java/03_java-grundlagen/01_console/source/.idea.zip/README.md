<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Ausgabe auf die Kommandozeile

Mit diesen Übungen kannst du dein Wissen über die Ausgabe auf die Kommandozeile (Konsole) vertiefen.

## Voraussetzung

- Du weisst, was mit Konsole gemeint ist.
- Du kannst Ausgaben auf die Konsole machen.
- Du weisst wie und warum man Zeichen escapen muss.

<itninja download lab="All"/>

## Aufgabe 1 - Hello World

<itninja description lab="HelloWorld">
Passe den Code an damit `Hello World` auf der Konsole ausgegeben wird.
</itninja>

<itninja source lab="HelloWorld" />

<itninja output lab="HelloWorld" />

## Aufgabe 2 - Ascii House

<itninja description lab="AsciiHouse">
Zeichne ein Haus in der Konsole. Du darfst dazu folgende Zeichen verwenden:

- `'/'`, `'\'`, `'+'`, `'-'`, `'_'`, `'['`, `']'`, `'|'`, Leerzeichen (`' '`)
</itninja>

<itninja source lab="AsciiHouse" />

> **Hinweis:** Vorsicht bei `'\'`, das ist ein besonderes Zeichen in einem String und muss escaped werden, das
> heisst für ein `'\'` muss man innerhalb von einem String das Zeichen zweimal schreiben → `".\\."`

Falls unklar ist, was hier gemeint ist, schau dir [ASCII-Art](https://de.wikipedia.org/wiki/ASCII-Art) an.

Hier eine Katze als Beispiel:

```console
 /\_/\
( o.o )
 > ^ <
```

## Aufgabe 3 - Ascii Swiss Flag

<itninja description lab="AsciiSwissFlag">
Zeichne eine Schweizer Fahne. Die Fahne muss einen Rahmen haben. Du darfst dazu
folgende Zeichen verwenden:

- Im Rahmen: `'|'`, `'-'`, `'+''`, Leerzeichen (`' '`)
- Innerhalb: `'|'`, `'-'`, `'+'`, `'*'`, `'='`, `'@''`, Leerzeichen (`' '`)
</itninja>

<itninja source lab="AsciiSwissFlag" />

Falls unklar ist, was hier gemeint ist, schau dir [ASCII-Art](https://de.wikipedia.org/wiki/ASCII-Art) an.

Hier ist die japanische Flagge als Beispiel:

```console
 ------------------
|                  |
|       @@@@       |
|     @@@@@@@@     |
|    @@@@@@@@@@    |
|     @@@@@@@@     |
|       @@@@       |
|                  |
 ------------------
```
