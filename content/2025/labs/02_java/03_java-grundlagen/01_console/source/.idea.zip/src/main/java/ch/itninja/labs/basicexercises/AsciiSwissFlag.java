package ch.itninja.labs.basicexercises;

public class AsciiSwissFlag {

    private AsciiSwissFlag() {
        // Prevent instantiation
    }

    //<itninja source lab="AsciiSwissFlag">
    public static void printSwissFlag(){

        //<itninja solution lab="AsciiSwissFlag">
        System.out.println(" _________ ");
        System.out.println("|         |");
        System.out.println("|   +++   |");
        System.out.println("|   +++   |");
        System.out.println("| +++++++ |");
        System.out.println("|   +++   |");
        System.out.println("|   +++   |");
        System.out.println("|_________|");
        //</itninja>

    }
    //</itninja>
}
