<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Strings

Mit diesen Übungen kannst du dein Wissen zum Thema Strings vertiefen.

#### Voraussetzung

- Du weisst was ein String ist.
- Du kannst eigene Packages und Methoden erstellen

<itninja download lab="All" />

## Ausgangslage

Du hast den folgenden String:

```
String poem = """
        Ein Ninja leise wie der Wind,
        Seine Waffen stets geschwind.
        "Shurikens" fliegen, scharf und schnell,
        Klingen funkeln, furchterregend hell.
        "Nunchakus" wirbeln im Tanz,
        Mit jedem Schlag, im Vorteil er ganz.
        Seine Waffen, geheim und klug,
        Begleiten ihn bei jedem Zug.""";
```

{{< ninja info >}}
Schreibe für jede Aufgabe eine eigene Methode, welche den String als Parameter nimmt.
Passe die `main(...)` Methode an, um deinen Quellcode aufzurufen.
{{< /ninja >}}

## Aufgabe 1 - Wörter zählen

Gib in der Konsole die Anzahl Wörtern aus. Als Wort gilt alles was eine Folge von Buchstaben und Zahlen sind. 

{{< ninja warning >}}
Die Methode `String.split(...)` darf in dieser Aufgabe nicht verwendet werden. `String.split(...)` wird erst in einem
späteren Modul behandelt.
{{< /ninja >}}

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\main\java\ch\itninja\labs\Main.java](./source/#src-main-java-ch-itninja-labs-main-java):

```java
    public static void main(String[] args) {

        // IT-Ninja: rufe hier deine Methoden auf und gib die Resultate auf der Konsole aus
    }
```

## Aufgabe 2 - Grossbuchstaben

Gib den Text in Grossbuchstaben aus.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\main\java\ch\itninja\labs\Main.java](./source/#src-main-java-ch-itninja-labs-main-java):

```java
    public static void main(String[] args) {

        // IT-Ninja: rufe hier deine Methoden auf und gib die Resultate auf der Konsole aus
    }
```

## Aufgabe 2 - Punkte setzen
Gib den Text so aus, dass jedes Leerzeichen mit einem Punkt ersetzt wurde.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\main\java\ch\itninja\labs\Main.java](./source/#src-main-java-ch-itninja-labs-main-java):

```java
    public static void main(String[] args) {

        // IT-Ninja: rufe hier deine Methoden auf und gib die Resultate auf der Konsole aus
    }
```

## Aufgabe 2 - Wort ausschneiden
Schneide das Wort “Shurikens” aus. Ermittle hierfür die Position des Wortes anhand des "-Zeichens. 

**Hinweis:** Die indexOf()-Methode bietet ein optionales Argument fromIndex an. Übergibst du die Position des ersten
Anführungszeichen + 1, dann wird die Position des zweiten zurückgegeben.

{{< ninja warning >}}
Die Methode `String.replace(...)` darf in dieser Aufgabe nicht verwendet werden.
{{< /ninja >}}

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\main\java\ch\itninja\labs\Main.java](./source/#src-main-java-ch-itninja-labs-main-java):

```java
    public static void main(String[] args) {

        // IT-Ninja: rufe hier deine Methoden auf und gib die Resultate auf der Konsole aus
    }
```
