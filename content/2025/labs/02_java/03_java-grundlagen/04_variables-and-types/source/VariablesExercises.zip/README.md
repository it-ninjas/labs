<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Variablen und bedingte Anweisungen

Mit diesen Übungen kannst du dein Wissen über bedingte Ausführung vertiefen.

#### Voraussetzung

- Du weisst was Variablen sind.
- Du kannst eine Variable deklarieren und initialisieren.
- Du weisst was primitive Datentypen sind.

<itninja download lab="All" />

## Aufgabe 1 - Hello It-Ninja

<itninja description lab="HelloName">
Erstelle eine Variable, welche deinen Namen beinhaltet.
Gib `Hello [name]` auf der Konsole aus.
</itninja>

<itninja source lab="HelloName" />

<itninja output lab="HelloName" />
