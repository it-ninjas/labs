package ch.itninja.labs.basicexercises;


/**
 * Utility class providing methods for basic Hello Name output.
 */
public class HelloName {

    private HelloName() {
        // Prevent instantiation
    }

    //<itninja source lab="HelloName">
    public static void printHelloName(){

        //<itninja solution lab="HelloName">
        String name = "It-Ninja";
        System.out.println("Hello " + name);
        //</itninja>

    }
    //</itninja>
}
