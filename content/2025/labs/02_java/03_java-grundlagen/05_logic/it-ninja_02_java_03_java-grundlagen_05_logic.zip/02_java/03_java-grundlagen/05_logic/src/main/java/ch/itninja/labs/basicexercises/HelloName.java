package ch.itninja.labs.basicexercises;


/**
 * Utility class providing methods for basic Hello Name output.
 */
public class HelloName {

    private HelloName() {
        // Prevent instantiation
    }

    public static void printHelloName(){

        // IT-Ninja: Füge hier Deinen Code ein...

    }
}
