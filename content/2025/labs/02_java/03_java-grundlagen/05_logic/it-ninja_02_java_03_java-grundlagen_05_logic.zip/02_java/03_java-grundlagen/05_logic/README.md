<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Einfache Berechnungen

Mit diesen Übungen kannst du dein Wissen über einfache Berechnungen vertiefen.

#### Voraussetzung

- Du weisst, wie man in Java mit Zahlen rechnet und Zahlen vergleicht.

<itninja download lab="All" />

## Aufgabe 1 - geometrische Berechnungen

Passe die folgenden Methoden an. Berechne Flächen, Umfang und Volumen und gib das Resultat auf der Konsole aus:

- `Das Rechteck mit a=[value1]cm und b=[value2]cm hat eine Fläche von [result]cm2.`
- `Das Dreieck mit g=[value1]cm und h=[value2]cm hat eine Fläche von [result]cm2.`
- `Der Kreis mit dem Radius [value]cm hat eine Fläche von [result]cm2.`
- `Das Rechteck mit a=[value1]cm und b=[value2]cm hat einen Umfang von [result]cm.`

Wobei in der Ausgabe die Platzhalter mit den eckigen Klammern durch die entsprechenden Zahlen ersetzt werden sollen.
Ganzzahlen sollen ohne '.' und Nachkommastellen angezeigt werden, Dezimalzahlen mit 2 Stellen hinter dem Punkt.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\main\java\ch\itninja\labs\basicexercises\CalculateForms.java](./source/#src-main-java-ch-itninja-labs-basicexercises-calculateforms-java):

```java
    public static void printRectArea(int sideA, int sideB) {

        // IT-Ninja: Füge hier Deinen Code ein:
    }

    public static void printTriangleArea(int sideC, int heightC) {

        // IT-Ninja: Füge hier Deinen Code ein:
    }

    public static void printCircleArea(int radius) {

        // IT-Ninja: Füge hier Deinen Code ein:
    }

    public static void printRectPerimeter(int sideA, int sideB) {

        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

### Rechteck Flächenberechnung

<itninja output lab="CalculateForms.RectArea" />

### Dreieck Flächenberechnung

<itninja output lab="CalculateForms.RectArea" />

## Aufgabe 2 - Checkout

Passe die folgende Methode an. Erstelle für die untenstehende Einkaufsliste für jeden Artikel eine Variable und weise
der Variable den entsprechenden Wert zu:

- Apfel: CHF 0.50
- Brot: CHF 1.10
- Milch: CHF 2.30
- Ei: CHF 0.60
- Butter: CHF 1.80

Zähle die Preise der Produkte zusammen und gib das Resultat auf der Konsole aus:

- `Alle Artikel zusammen kosten CHF [total].`

Wobei in der Ausgabe `[total]` durch das tatsächliche Werte ersetzt werden sollen.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[](./source/#):

```java

```



## Aufgabe 3 - Alter in Monaten

Passe die folgende Methode an. Berechne dein Alter in ganzen Monaten. Zähle den Monat wo du geboren wurdest als ganzen
Monat dazu. Der aktuelle Monat wird nur berücksichtigt, wenn mindestens 14 Tage vom Monat vorbei sind.

- `Ich bin am dd.mm.yyyy geboren und heute am dd.mm.yyyy z Monate alt`

Wobei in der Ausgabe `dd.mm.yyyy` durch das tatsächliche Datum von Deinem Geburtstag resp. dem heutigen Datum ersetzt
werden soll und `z` durch die Anzahl Monate.

> Im Quellcode findest du bei der Methode welche du anpassen musst auch statische Variablen (`dayOfBirth`,
> `monthOfBirth`, `yearOfBirth`, `dayOfToday`, `monthOfToday`, `yearOfToday`). Passe diese Variablen an und nutze sie in
> der Methode. Es wird erwartet, dass sich eine Änderung einer dieser Variablen auf die Berechnung aber auch auf die
> Ausgabe inder Konsole auswirkt.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[](./source/#):

```java

```



## Aufgabe 4 - Zahlenspiel

Passe die folgende Methode an. Berechne dein Alter in ganzen Monaten. Zähle den Monat wo du geboren wurdest als ganzen
Monat dazu. Der aktuelle Monat wird nur berücksichtigt, wenn mindestens 14 Tage vom Monat vorbei sind.

- `Ich bin am dd.mm.yyyy geboren und heute am dd.mm.yyyy z Monate alt`

Wobei in der Ausgabe `dd.mm.yyyy` durch das tatsächliche Datum von Deinem Geburtstag resp. dem heutigen Datum ersetzt
werden soll und `z` durch die Anzahl Monate.

> Im Quellcode findest du bei der Methode welche du anpassen musst auch statische Variablen (`dayOfBirth`,
> `monthOfBirth`, `yearOfBirth`, `dayOfToday`, `monthOfToday`, `yearOfToday`). Passe diese Variablen an und nutze sie in
> der Methode. Es wird erwartet, dass sich eine Änderung einer dieser Variablen auf die Berechnung, aber auch auf die
> Ausgabe in der Konsole auswirkt.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[](./source/#):

```java

```


