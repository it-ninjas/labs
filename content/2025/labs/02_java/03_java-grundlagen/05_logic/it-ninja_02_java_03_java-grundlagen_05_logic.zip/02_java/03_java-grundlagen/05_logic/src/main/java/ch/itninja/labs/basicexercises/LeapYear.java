package ch.itninja.labs.basicexercises;

/**
 * Utility class providing methods for leap year calculation.
 */
public class LeapYear {

    // IT-Ninja: Füge hier Deinen Code ein...

    private LeapYear() {
        // Prevent instantiation
    }

    public static boolean isLeapYear(int year) {

        // IT-Ninja: Füge hier Deinen Code ein...

    }
}
