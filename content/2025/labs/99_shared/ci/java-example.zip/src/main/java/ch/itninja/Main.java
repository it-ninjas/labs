package ch.itninja;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

    public static int ggt(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
