package ch.itninja.labs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    // ...existing code...

    @Test
    void ggtBasic() {
        assertEquals(6, Main.ggt(24, 30));
    }

}
