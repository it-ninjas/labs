package ch.itninja.labs;

/**
 * Entry point for the It-Ninja basic exercises.
 */
public class Main {

    public static void main(String[] args) {

        // IT-Ninja: rufe hier deine Methoden auf und gib die Resultate auf der Konsole aus
    }
}
