<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Packages

Mit diesen Übungen kannst du dein Wissen zum Thema Packages vertiefen.

#### Voraussetzung

- Du weisst was ein Package ist.

<itninja download lab="All" />

## Aufgabe

Erstelle ein eigenes Package, welches dir ein paar mathematische Hilfsfunktionen zur Verfügung
stellt:

* Kleinerer Wert von 2 Integer Zahlen
* Grösserer Wert von 2 Integer Zahlen
* Absoluter Wert von einer Integer Zahl
* Differenz von 2 Zahlen

**Achtung:** Das von dir erstellte Package darf nicht `ch.itninja.labs` enthalten.

Im zur Übung gehörendem Source kannst Du die Änderung an folgender Stelle machen:  
[src\main\java\ch\itninja\labs\Main.java](./source/#src-main-java-ch-itninja-labs-main-java):

```java
    public static void main(String[] args) {

        // IT-Ninja: rufe hier deine Methoden auf und gib die Resultate auf der Konsole aus
    }
```
