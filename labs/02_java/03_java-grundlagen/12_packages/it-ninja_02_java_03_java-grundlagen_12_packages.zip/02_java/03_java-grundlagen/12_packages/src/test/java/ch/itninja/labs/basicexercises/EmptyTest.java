package ch.itninja.labs.basicexercises;

import ch.itninja.labs.util.ItNinjaOutput;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class EmptyTest {
    @Test
    void emptyTest() {

        // This is just a placeholder for upcoming tests. Required by LabGenerator
    }
}
