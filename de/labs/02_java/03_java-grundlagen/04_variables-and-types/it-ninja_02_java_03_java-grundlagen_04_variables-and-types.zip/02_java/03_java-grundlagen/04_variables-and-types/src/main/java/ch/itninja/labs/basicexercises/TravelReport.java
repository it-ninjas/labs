package ch.itninja.labs.basicexercises;

/**
 * Gibt einen Reisebericht eines it-ninjas formatiert mit printf aus.
 */
public class TravelReport {

    private TravelReport() {
        // Prevent instantiation
    }

    public static void printTravelReport() {

        // IT-Ninja: Füge hier Deinen Code ein...
    }
}
